﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VideoRentalApp.Migrations
{
    public partial class ABCDEhg : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
